import type {
  NatalChart,
  PlanetKey,
  ReportSection,
  Reading,
  Aspect,
  AspectType,
} from "@/types/astro";
import {
  SIGNS,
  ORDINALS,
  PLANET_META,
  SIGN_QUALITY,
  HOUSE_DOMAIN,
  HOUSE_THROUGH,
  HOUSE_WORK,
} from "@/constants/astro";
import { aspectsFor, ASPECT_WORD } from "@/lib/aspects";
import { deriveFunctions, derivePrimary } from "@/lib/archetypes";
import { generateHeroJourney } from "@/lib/heroJourney";

type Element = "fire" | "earth" | "air" | "water";
type Modality = "cardinal" | "fixed" | "mutable";

const ELEMENT_FLOW: Record<Element, string> = {
  fire: "ideas arrive as sudden ignition — you move first and refine later, generating heat others gather around.",
  earth: "ideas arrive as tangible problems to solve — you trust what can be measured, built, and sustained.",
  air: "ideas arrive as connections between concepts — you think in networks, comparisons, and language.",
  water: "ideas arrive as felt impressions — you sense the shape of a thing before you can name it.",
};

const MODALITY_DECISION: Record<Modality, string> = {
  cardinal: "You decide by launching: commitment comes early and creates the momentum that carries the work.",
  fixed: "You decide by holding: once set, you concentrate force and resist premature change.",
  mutable: "You decide by adjusting: you keep options open and let the final form emerge through iteration.",
};

const BOTTLENECK: Record<Modality, string> = {
  cardinal: "you may launch faster than you can sustain, leaving initiatives half-built",
  fixed: "you may hold a course long after it has stopped serving the work",
  mutable: "you may keep adapting so long that nothing is ever finalized",
};

// The role each engine plays in the cycle — no "point" language.
const ROLE: Partial<Record<PlanetKey, string>> = {
  sun: "As the origin of your creative force, this placement describes how your vision is born and the instinct that first sets it in motion.",
  moon: "Receiving the Sun's vision, the Moon turns raw intent into perception — the felt sense of what is real and what matters.",
  mars: "With perception formed, Mars converts awareness into force: the first physical movement against resistance.",
  mercury: "Mars's force now needs a signal; Mercury encodes it into language, thought, and repeatable communication.",
  jupiter: "Mercury's message now seeks reach; Jupiter expands it, multiplying its range, influence, and available potential.",
  venus: "Jupiter's expansion now needs discernment; Venus distills it into value, deciding what is worth keeping and what it is worth.",
  saturn: "Venus's value now demands form; Saturn provides the structure, boundaries, and durability required for it to endure.",
};

const OCTAVE_TEXT: Partial<Record<PlanetKey, (sign: string, houseOrd: string) => string>> = {
  pluto: (sign, houseOrd) =>
    `♇ Pluto — Mars's higher octave — occupies ${sign} in the ${houseOrd} house, extending impact beyond personal action into collective transformation. Where Mars applies force to create change, Pluto intensifies it through elimination, regeneration, and evolution — dismantling what is obsolete so a more powerful system can take its place.`,
  uranus: (sign, houseOrd) =>
    `♅ Uranus — Mercury's higher octave — sits in ${sign} in the ${houseOrd} house, adding unconventional pattern recognition and sudden insight to your communication. It is the higher intelligence behind Mercury's expression, bringing original connections and the ability to translate emerging ideas into new language.`,
  neptune: (sign, houseOrd) =>
    `♆ Neptune — Venus's higher octave — moves through ${sign} in the ${houseOrd} house, expanding value beyond personal preference into collective imagination. It dissolves ordinary definitions of worth and draws you toward ideals and visions that carry meaning beyond the individual.`,
};

function aspectPhrase(chart: NatalChart, key: PlanetKey): string {
  const list = aspectsFor(key, chart.aspects).slice(0, 4);
  if (!list.length) {
    return "It forms no exact major aspects, so it runs as a relatively self-contained engine within your chart.";
  }
  const byType = new Map<AspectType, string[]>();
  for (const a of list) {
    const other = a.a === key ? a.b : a.a;
    const arr = byType.get(a.type) ?? [];
    arr.push(PLANET_META[other].name);
    byType.set(a.type, arr);
  }
  const groups: string[] = [];
  for (const [type, names] of byType) {
    groups.push(`${ASPECT_WORD[type]} ${joinNames(names)}`);
  }
  const hard = list.filter((a) => a.type === "square" || a.type === "opposition").length;
  const tail =
    hard >= 2
      ? "asking this function to reconcile competing pressures before it runs clean"
      : hard === 1
      ? "adding one clear line of friction that sharpens the function when consciously managed"
      : "giving this function natural allies it can draw on";
  return `Its major aspects — ${joinList(groups)} — wire it into those engines, ${tail}.`;
}

function joinNames(names: string[]): string {
  if (names.length === 1) return names[0];
  if (names.length === 2) return `${names[0]} and ${names[1]}`;
  return `${names.slice(0, -1).join(", ")}, and ${names[names.length - 1]}`;
}

function joinList(items: string[]): string {
  if (items.length === 1) return items[0];
  if (items.length === 2) return `${items[0]}, ${items[1]}`;
  return `${items.slice(0, -1).join(", ")}, ${items[items.length - 1]}`;
}

function field(houseIdx: number): string {
  return HOUSE_DOMAIN[houseIdx].replace("the arena of", "the field of");
}

function planetSection(chart: NatalChart, key: PlanetKey): ReportSection {
  const meta = PLANET_META[key];
  const pos = chart.positions[key];
  const sign = SIGNS[pos.signIndex];
  const hi = pos.house - 1;
  const houseOrd = ORDINALS[hi];
  const el = sign.element as Element;
  const mod = sign.modality as Modality;
  const fnLower = meta.fn.toLowerCase();
  const retro = pos.retrograde
    ? " Moving retrograde, this process turns inward first, refining through reflection before it externalizes."
    : "";

  const p1 =
    `${meta.glyph} ${meta.name} — your engine of ${meta.fn} — occupies ${sign.name} in the ${houseOrd} house, ${HOUSE_DOMAIN[hi]}. ` +
    `${ROLE[key] ?? ""} ${sign.name} brings a ${mod} ${el} quality: ${SIGN_QUALITY[pos.signIndex]}. ` +
    `In the ${houseOrd} house, this finds expression through ${HOUSE_THROUGH[hi]}. ` +
    `${aspectPhrase(chart, key)}${retro}`;

  const p2 =
    `In practice, ${ELEMENT_FLOW[el]} ${MODALITY_DECISION[mod]} ` +
    `Seated in ${field(hi)}, your ${fnLower} is most productive when the work involves ${HOUSE_WORK[hi]}. ` +
    `The strength here is a dependable way to move ${fnLower} from potential into reality; the bottleneck appears when the ${mod} tempo runs against its grain — ${BOTTLENECK[mod]}. ` +
    `Develop this engine by pairing its ${el} instinct with the discipline of the stage that follows.`;

  const paragraphs = [p1, p2];
  if (meta.octave) {
    const oPos = chart.positions[meta.octave];
    const oSign = SIGNS[oPos.signIndex];
    const oHouse = ORDINALS[oPos.house - 1];
    const fn = OCTAVE_TEXT[meta.octave];
    if (fn) paragraphs.push(fn(oSign.name, oHouse));
  }

  return {
    kind: "planet",
    order: 0,
    title: `${meta.name} · ${meta.fn}`,
    subtitle: `${sign.name} — ${houseOrd} House`,
    glyph: meta.glyph,
    planetKeys: meta.octave ? [key, meta.octave] : [key],
    paragraphs,
  };
}

// --- Thresholds ---------------------------------------------------------------
// Woven between the engines they transform: Impact (Mars -> Mercury), Will
// (Jupiter -> Venus), Retention (Saturn, the close of the cycle).

function impactThreshold(chart: NatalChart): ReportSection {
  const mars = SIGNS[chart.positions.mars.signIndex].name;
  const mercury = SIGNS[chart.positions.mercury.signIndex].name;
  return {
    kind: "threshold",
    order: 0,
    title: "Impact Threshold",
    subtitle: "Where Force Becomes Direction",
    glyph: "◬",
    planetKeys: [],
    paragraphs: [
      "Between raw force and articulate signal stands the Impact Threshold — not a planet, but a transformation event. This is the point where energy alone is no longer enough. Force must become directed, because movement without aim only creates expenditure.",
      `Your Mars in ${mars} is the ignition of force: instinct, action, heat, and the drive to initiate. Mars has generated momentum through direct action, but force eventually reaches the point where intensity alone cannot increase impact. Before your Mercury in ${mercury} can translate that energy into meaningful signal, Mars must refine itself into direction — the impulse has to learn where to land.`,
      "Cross this threshold and action becomes targeted rather than reactive. Energy stops dispersing and begins producing a deliberate effect.",
    ],
  };
}

function willThreshold(chart: NatalChart): ReportSection {
  const jupiter = SIGNS[chart.positions.jupiter.signIndex].name;
  const venus = SIGNS[chart.positions.venus.signIndex].name;
  return {
    kind: "threshold",
    order: 0,
    title: "Will Threshold",
    subtitle: "Where Expansion Becomes Purpose",
    glyph: "◬",
    planetKeys: [],
    paragraphs: [
      "Between expansion and value stands the Will Threshold. Growth eventually reaches the point where more possibilities create more fragmentation rather than more progress. Expansion must be refined into purpose.",
      `Your Jupiter in ${jupiter} is expansion through vision, reach, and possibility. Jupiter opens the field, but an expanded field still requires selection. Before your Venus in ${venus} can crystallize value, Jupiter's abundance must be narrowed into intention — possibility has to become purposeful investment.`,
      "Cross this threshold and growth gains meaning. Expansion is no longer measured by how much can be added, but by how clearly energy is directed toward what matters.",
    ],
  };
}

function retentionThreshold(chart: NatalChart): ReportSection {
  const saturn = SIGNS[chart.positions.saturn.signIndex].name;
  return {
    kind: "threshold",
    order: 0,
    title: "Retention Threshold",
    subtitle: "Where Structure Becomes Permanence",
    glyph: "♄",
    planetKeys: [],
    paragraphs: [
      "The final threshold belongs to Saturn — the principle of time, structure, and endurance. Creation reaches completion only when what has been built can survive beyond the cycle that created it.",
      `Your Saturn in ${saturn} is the work of giving form to the intangible: turning vision, intuition, and ideals into something that can exist within reality. Saturn asks what is strong enough to remain and what must dissolve. Retention is the act of preserving what has proven its value while releasing what cannot sustain the structure.`,
      "Cross this threshold and experience becomes architecture. The lesson is no longer something you learned — it becomes part of the system itself.",
    ],
  };
}

export function generateReading(chart: NatalChart): Reading {
  const functions = deriveFunctions(chart);
  const primary = derivePrimary(functions, chart);

  // Engines in cycle order with thresholds woven in at their turning points.
  const planetSections: ReportSection[] = [];
  const add = (s: ReportSection) => {
    s.order = planetSections.length;
    planetSections.push(s);
  };

  add(planetSection(chart, "sun"));
  add(planetSection(chart, "moon"));
  add(planetSection(chart, "mars")); // + Pluto octave
  add(impactThreshold(chart)); // Mars -> Mercury
  add(planetSection(chart, "mercury")); // + Uranus octave
  add(planetSection(chart, "jupiter"));
  add(willThreshold(chart)); // Jupiter -> Venus
  add(planetSection(chart, "venus")); // + Neptune octave
  add(planetSection(chart, "saturn"));
  add(retentionThreshold(chart)); // Saturn closes the cycle

  const heroJourney = generateHeroJourney(chart, primary);

  return {
    chart,
    planetSections,
    functions,
    primary,
    heroJourney,
  };
}

// Re-exported for convenience where a raw aspect list needs typing.
export type { Aspect };
