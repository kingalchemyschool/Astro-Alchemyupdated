import type { PlanetKey, Reading } from "@/types/astro";
import { SIGNS, PLANET_META } from "@/constants/astro";
import {
  crossAspects,
  HARMONIOUS,
  CHALLENGING,
  ASPECT_WORD,
  type CrossAspect,
} from "@/lib/aspects";

export interface PlanetPairNote {
  key: PlanetKey;
  aSign: string;
  bSign: string;
  note: string;
}

export interface Comparison {
  nameA: string;
  nameB: string;
  summary: string[];
  planetPairs: PlanetPairNote[];
  archetype: { a: string; b: string; paragraphs: string[] };
  strengths: string[];
  frictions: string[];
  solutions: string[];
}

const CORE: PlanetKey[] = ["sun", "moon", "mercury", "venus", "mars", "jupiter", "saturn"];

const PAIR_LENS: Record<PlanetKey, string> = {
  sun: "shared vision and creative direction",
  moon: "emotional attunement and how you read each other",
  mercury: "communication and how information moves between you",
  venus: "values, taste, and what you both choose to nurture",
  mars: "drive, initiative, and how you split the labor",
  jupiter: "growth, optimism, and the scale of what you attempt",
  saturn: "structure, commitment, and who holds the frame",
  uranus: "disruption",
  neptune: "dissolution",
  pluto: "regeneration",
};

// Per-engine flavor for the same-planet comparison, split by whether the
// dominant contact reads easy or hard. Keeps every engine's note distinct.
const FLAVOR: Record<PlanetKey, { easy: string; hard: string }> = {
  sun: {
    easy: "your core directions point the same way, so leadership can pass back and forth without a turf war.",
    hard: "you each hold a firm, differing sense of where the work should go — decide whose vision leads which project before you start, not halfway through.",
  },
  moon: {
    easy: "you read each other's moods accurately, which makes the daily grind of working together feel safe.",
    hard: "you process feelings on different frequencies; assume the occasional misread and check in out loud rather than guessing.",
  },
  mercury: {
    easy: "ideas survive the trip between you intact — briefs, notes, and half-thoughts arrive as sent.",
    hard: "you organize thinking differently, so put decisions in writing before either of you treats them as settled.",
  },
  venus: {
    easy: "your tastes and sense of worth overlap, so you rarely argue about what is good enough to ship.",
    hard: "you prize different things — agree on what 'quality' means here before credit or money enters the room.",
  },
  mars: {
    easy: "your working tempos sync, so effort compounds instead of canceling out.",
    hard: "you both want to drive; hand one of you the kickoff and the other the finish rather than gripping the same wheel.",
  },
  jupiter: {
    easy: "you dream at a compatible scale, so plans grow without one of you feeling reckless or reined in.",
    hard: "one of you always wants to go bigger — set the size of the bet on purpose instead of by whoever pushes hardest.",
  },
  saturn: {
    easy: "you agree on standards and deadlines, so the frame holds without constant renegotiation.",
    hard: "you carry structure differently; name who owns the deadlines and the final 'no,' or you will both assume it is the other.",
  },
  uranus: { easy: "", hard: "" },
  neptune: { easy: "", hard: "" },
  pluto: { easy: "", hard: "" },
};

const HARM_TAIL = [
  "the two reinforce each other with almost no effort",
  "this pairing pulls in the same direction",
  "each one quietly covers the other's blind spot",
  "lean on this when the collaboration gets tense elsewhere",
];

const FRIC_TAIL = [
  "expect heat here until it is named out loud",
  "friction collects here if nobody owns it",
  "this is where pace and priorities collide",
  "handled directly this becomes fuel; left alone it becomes resentment",
];

const SOLUTION_BY_PLANET: Partial<Record<PlanetKey, string>> = {
  sun: "When the visions diverge, carve the project into clearly owned domains so each of you leads something outright instead of co-steering everything.",
  moon: "Open working sessions with a ten-second gut-check — say the mood out loud so it informs the work instead of leaking into it.",
  mercury: "Default to written decisions; a shared doc turns two thinking styles into a paper trail instead of a misunderstanding.",
  venus: "Define 'good enough to ship' together up front, so taste differences get settled on paper rather than in the final hour.",
  mars: "Run effort in sequence — one owns the kickoff, the other owns the finish. Never point both drives at the same task.",
  jupiter: "Size each bet on purpose: write down how big is too big before excitement sets the scale for you.",
  saturn: "Appoint one keeper of the frame — deadlines, standards, the final no. Split authority over structure is where labs quietly crack.",
};

function sig(x: CrossAspect): string {
  return `${x.a}-${x.b}-${x.type}`;
}

interface Rel {
  clause: string;
  easy: boolean;
}

function signRel(aIdx: number, bIdx: number): Rel {
  const A = SIGNS[aIdx];
  const B = SIGNS[bIdx];
  const raw = Math.abs(aIdx - bIdx);
  const dist = Math.min(raw, 12 - raw);
  switch (dist) {
    case 0:
      return { clause: "meet in the same sign", easy: true };
    case 2:
      return { clause: `${A.name} and ${B.name} form an easy sextile`, easy: true };
    case 3:
      return { clause: `${A.name} squares ${B.name} (same ${A.modality} mode, clashing elements)`, easy: false };
    case 4:
      return { clause: `${A.name} and ${B.name} trine through the shared ${A.element} element`, easy: true };
    case 6:
      return { clause: `${A.name} sits opposite ${B.name} across the same axis`, easy: false };
    default: // 1 or 5
      return { clause: `${A.name} and ${B.name} sit at an off-angle that needs translating`, easy: false };
  }
}

function planetNote(
  key: PlanetKey,
  aIdx: number,
  bIdx: number,
  nameA: string,
  nameB: string,
  cross: CrossAspect[],
  used: Set<string>
): string {
  const rel = signRel(aIdx, bIdx);
  const aSign = SIGNS[aIdx].name;
  const bSign = SIGNS[bIdx].name;

  // Prefer a not-yet-cited hard contact involving this engine; else a soft one.
  const involving = cross.filter(
    (x) => (x.a === key || x.b === key) && !used.has(sig(x))
  );
  const hard = involving
    .filter((x) => CHALLENGING.includes(x.type))
    .sort((m, n) => m.orb - n.orb)[0];
  const soft = involving
    .filter((x) => HARMONIOUS.includes(x.type))
    .sort((m, n) => m.orb - n.orb)[0];
  const chosen = hard ?? soft;

  let crossClause = "";
  let hardContact = false;
  if (chosen) {
    used.add(sig(chosen));
    hardContact = CHALLENGING.includes(chosen.type);
    crossClause = `, plus ${nameA}'s ${PLANET_META[chosen.a].name} ${ASPECT_WORD[chosen.type]} ${nameB}'s ${PLANET_META[chosen.b].name} (orb ${chosen.orb}°)`;
  }

  const flavor = hardContact || !rel.easy ? FLAVOR[key].hard : FLAVOR[key].easy;

  return `On ${PAIR_LENS[key]}: ${nameA}'s ${aSign} and ${nameB}'s ${bSign} ${rel.clause}${crossClause}. In practice, ${flavor}`;
}

function buildSolutions(
  a: Reading,
  b: Reading,
  cross: CrossAspect[],
  nameA: string,
  nameB: string
): string[] {
  const out: string[] = [];
  const seen = new Set<PlanetKey>();

  for (const x of cross.filter((c) => CHALLENGING.includes(c.type))) {
    for (const k of [x.a, x.b] as PlanetKey[]) {
      if (seen.has(k)) continue;
      const tip = SOLUTION_BY_PLANET[k];
      if (tip) {
        out.push(tip);
        seen.add(k);
      }
    }
    if (out.length >= 3) break;
  }

  // Close with a handoff instruction tied to their archetypes and thresholds.
  const differ = a.primary.name !== b.primary.name;
  out.push(
    differ
      ? `Run the cycle as a relay: ${nameA} owns the stages ${a.primary.name} is built for, ${nameB} owns ${b.primary.name}'s, and you hand off at each threshold instead of both hovering over every step.`
      : `You share ${a.primary.name} as a primary archetype, so deliberately assign the functions neither of you defaults to — split the cycle at the thresholds so identical instincts do not double up and leave the same gaps.`
  );

  return out;
}

function buildArchetype(a: Reading, b: Reading, nameA: string, nameB: string) {
  const same = a.primary.name === b.primary.name;
  const lineA = a.primary.line.replace(/\.$/, "");
  const lineB = b.primary.line.replace(/\.$/, "");
  return {
    a: a.primary.name,
    b: b.primary.name,
    paragraphs: [
      `${nameA} leads as ${a.primary.name} — the one who ${lineA}. ${nameB} leads as ${b.primary.name} — the one who ${lineB}.`,
      same
        ? `Sharing a primary archetype means you see the work the same way: a real accelerant, and a hidden trap, because you will reinforce each other's instincts including the blind ones. Put someone deliberately in charge of the function neither of you naturally runs.`
        : `Because your archetypes differ, each of you covers a stage the other under-serves. This partnership works best when you stop competing to run the same step and start handing the work along the cycle — ${a.primary.name} into ${b.primary.name} and back again.`,
    ],
  };
}

function reelLine(
  x: CrossAspect,
  a: Reading,
  b: Reading,
  nameA: string,
  nameB: string,
  tail: string,
  connector: string
): string {
  const aSign = SIGNS[a.chart.positions[x.a].signIndex].name;
  const bSign = SIGNS[b.chart.positions[x.b].signIndex].name;
  return `${nameA}'s ${PLANET_META[x.a].name} in ${aSign} ${ASPECT_WORD[x.type]} ${nameB}'s ${PLANET_META[x.b].name} in ${bSign} (orb ${x.orb}°) — ${PAIR_LENS[x.a]} ${connector} ${PAIR_LENS[x.b]}; ${tail}.`;
}

export function compareCharts(a: Reading, b: Reading): Comparison {
  const nameA = a.chart.input.name?.trim() || "Person A";
  const nameB = b.chart.input.name?.trim() || "Person B";
  const cross = crossAspects(a.chart.positions, b.chart.positions);
  const good = cross.filter((x) => HARMONIOUS.includes(x.type)).length;
  const hard = cross.filter((x) => CHALLENGING.includes(x.type)).length;

  // Per-engine notes. Each consumes at most one contact so the highlight reels
  // below surface *different* contacts and nothing repeats across the reading.
  const used = new Set<string>();
  const planetPairs: PlanetPairNote[] = CORE.map((key) => {
    const aIdx = a.chart.positions[key].signIndex;
    const bIdx = b.chart.positions[key].signIndex;
    return {
      key,
      aSign: SIGNS[aIdx].name,
      bSign: SIGNS[bIdx].name,
      note: planetNote(key, aIdx, bIdx, nameA, nameB, cross, used),
    };
  });

  const harmPool = cross.filter((x) => HARMONIOUS.includes(x.type) && !used.has(sig(x)));
  const harmSource = harmPool.length ? harmPool : cross.filter((x) => HARMONIOUS.includes(x.type));
  const strengths = harmSource
    .slice(0, 4)
    .map((x, i) => reelLine(x, a, b, nameA, nameB, HARM_TAIL[i % HARM_TAIL.length], "meets"));

  const fricPool = cross.filter((x) => CHALLENGING.includes(x.type) && !used.has(sig(x)));
  const fricSource = fricPool.length ? fricPool : cross.filter((x) => CHALLENGING.includes(x.type));
  const frictions = fricSource
    .slice(0, 4)
    .map((x, i) => reelLine(x, a, b, nameA, nameB, FRIC_TAIL[i % FRIC_TAIL.length], "grinds against"));

  const strengthsOut = strengths.length
    ? strengths
    : [
        `No tight harmonies between your core engines — nothing runs on autopilot, but nothing is forced either. Whatever ease you find here, you will build on purpose.`,
      ];

  const frictionsOut = frictions.length
    ? frictions
    : [
        `No tight hard contacts between your core engines — friction here will come from habit and pace, not deep structural conflict.`,
      ];

  const solutions = buildSolutions(a, b, cross, nameA, nameB);

  const balance =
    good > hard
      ? `The lab runs warm — ${good} easy contacts to ${hard} hard ones, so momentum comes cheap and the real risk is coasting.`
      : hard > good
      ? `The lab runs hot — ${hard} hard contacts to ${good} easy ones, which is generative once named and corrosive while ignored.`
      : `The lab runs even — ${good} easy contacts and ${hard} hard ones, the mix that tends to build the most durable partnerships.`;

  const summary = [
    `Two blueprints, one bench. ${nameA} and ${nameB} get read engine by engine — all seven creative functions plus both Alchemist Archetypes — to see how the work actually moves when you build side by side.`,
    balance,
  ];

  const archetype = buildArchetype(a, b, nameA, nameB);

  return {
    nameA,
    nameB,
    summary,
    planetPairs,
    archetype,
    strengths: strengthsOut,
    frictions: frictionsOut,
    solutions,
  };
}
