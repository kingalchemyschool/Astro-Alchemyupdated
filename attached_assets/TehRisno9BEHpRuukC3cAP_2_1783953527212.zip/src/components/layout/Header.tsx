import { Link, useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";

export default function Header() {
  const { pathname } = useLocation();
  return (
    <header className="sticky top-0 z-40 border-b border-border/60 bg-background/80 backdrop-blur-md">
      <div className="container flex h-16 items-center justify-between">
        <Link to="/" className="flex items-center gap-3 group">
          <span className="glyph text-2xl text-primary transition-transform group-hover:rotate-12">
            ✷
          </span>
          <span className="font-serif text-xl font-semibold tracking-wide">
            Astro<span className="text-gradient-gold">boros</span>
          </span>
        </Link>
        <nav className="flex items-center gap-1">
          {[
            { to: "/", label: "Home" },
            { to: "/reading", label: "Blueprint" },
            { to: "/compare", label: "Compare" },
          ].map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={cn(
                "rounded-md px-4 py-2 text-sm font-medium transition-colors",
                pathname === item.to
                  ? "text-primary"
                  : "text-muted-foreground hover:text-foreground"
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
