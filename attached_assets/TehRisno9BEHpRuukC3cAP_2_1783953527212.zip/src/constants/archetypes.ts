import type { FunctionKey, PlanetKey } from "@/types/astro";

export interface ArchetypeOption {
  name: string;
  line: string;
}

export interface FunctionMeta {
  key: FunctionKey;
  title: string;
  tagline: string; // what its paid reading covers
  pair: [PlanetKey, PlanetKey];
  glyphs: [string, string];
  definition: string;
  archetypes: ArchetypeOption[]; // element -> index (fire, earth, air, water, [hard])
}

// The six fixed Alchemist Archetype functions. Each is a planet-pair
// relationship that generates a function; the specific archetype is derived
// from the user's placements.
export const FUNCTIONS: FunctionMeta[] = [
  {
    key: "translation",
    title: "Translation",
    tagline: "how your message gets translated and where it gets misconstrued",
    pair: ["moon", "mercury"],
    glyphs: ["☽", "☿"],
    definition:
      "The movement of internal experience into external expression. The Moon gathers perception, sensation, and memory; Mercury organizes it into language, meaning, and understanding. Together they transform what is felt and observed into something that can be interpreted, communicated, and shared.",
    archetypes: [
      { name: "The Storyteller", line: "transforms perception into narrative and expression." },
      { name: "The Teacher", line: "organizes knowledge into something others can understand." },
      { name: "The Messenger", line: "carries information between inner and outer worlds." },
      { name: "The Interpreter", line: "converts felt experience into meaning." },
      { name: "The Translator", line: "bridges different perspectives, systems, and languages." },
    ],
  },
  {
    key: "execution",
    title: "Execution",
    tagline: "how you execute your vision and turn intention into movement",
    pair: ["mercury", "mars"],
    glyphs: ["☿", "♂"],
    definition:
      "The movement of thought into action. Mercury provides information, strategy, and precision; Mars provides initiative, force, and direction. Together they transform ideas into decisions, plans into action, and intention into directed movement.",
    archetypes: [
      { name: "The Initiator", line: "converts ideas into immediate action." },
      { name: "The Tactician", line: "applies intelligence in real time to overcome obstacles." },
      { name: "The Strategist", line: "turns information into decisive action." },
      { name: "The Advocate", line: "uses communication as a force for movement and change." },
    ],
  },
  {
    key: "discipline",
    title: "Discipline",
    tagline: "how you develop skill and achieve your goal through mastery",
    pair: ["mars", "saturn"],
    glyphs: ["♂", "♄"],
    definition:
      "The refinement of force through limitation, repetition, and structure. Mars supplies the drive to act; Saturn shapes that drive through endurance and control. Together they transform raw effort into mastery, turning impulse into reliable power.",
    archetypes: [
      { name: "The Warrior", line: "directs force with control and purpose." },
      { name: "The Craftsman", line: "turns effort into expertise." },
      { name: "The Operator", line: "applies discipline to achieve consistent results." },
      { name: "The Master", line: "develops skill through repetition and refinement." },
    ],
  },
  {
    key: "capacity",
    title: "Capacity",
    tagline: "how to increase capacity and retain the results you create",
    pair: ["saturn", "jupiter"],
    glyphs: ["♄", "♃"],
    definition:
      "The process of increasing what a structure can contain. Saturn defines the boundaries and establishes the framework; Jupiter tests those limits and expands potential. Together they determine how much growth, complexity, and reach a system can sustainably support.",
    archetypes: [
      { name: "The Builder", line: "creates foundations for expansion." },
      { name: "The Engineer", line: "develops systems that withstand increased demand." },
      { name: "The Architect", line: "designs structures capable of holding greater vision." },
      { name: "The Steward", line: "manages resources and responsibility over time." },
    ],
  },
  {
    key: "cultivation",
    title: "Cultivation",
    tagline: "how growth becomes value worth nurturing and developing",
    pair: ["jupiter", "venus"],
    glyphs: ["♃", "♀"],
    definition:
      "The process of transforming expansion into value. Jupiter increases possibility; Venus selects what is meaningful, desirable, and worth developing. Together they determine what should be nurtured, refined, and brought into greater expression.",
    archetypes: [
      { name: "The Visionary", line: "recognizes opportunities and develops their potential." },
      { name: "The Cultivator", line: "nurtures resources into greater expression." },
      { name: "The Curator", line: "selects, refines, and elevates what matters." },
      { name: "The Alchemist", line: "transforms raw potential into tangible value." },
    ],
  },
  {
    key: "integration",
    title: "Integration",
    tagline: "how value becomes integrated, embodied, and sustained",
    pair: ["venus", "moon"],
    glyphs: ["♀", "☽"],
    definition:
      "The process of bringing value into lived experience. Venus identifies what is desirable and meaningful; the Moon gives it emotional resonance, attachment, and continuity. Together they integrate what is valued into the self, allowing it to become embodied, nurtured, and sustained.",
    archetypes: [
      { name: "The Harmonizer", line: "creates alignment between desire and emotional experience." },
      { name: "The Guardian", line: "protects and preserves what is meaningful." },
      { name: "The Embodier", line: "transforms ideals into lived reality." },
      { name: "The Nurturer", line: "sustains what has value through care and connection." },
    ],
  },
];

export const FUNCTION_BY_KEY: Record<FunctionKey, FunctionMeta> = Object.fromEntries(
  FUNCTIONS.map((f) => [f.key, f])
) as Record<FunctionKey, FunctionMeta>;
