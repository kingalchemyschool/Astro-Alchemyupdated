import type { HeroJourney, NatalChart, PrimaryArchetype, PlanetKey } from "@/types/astro";
import { SIGNS, ORDINALS, HOUSE_DOMAIN } from "@/constants/astro";

function field(houseIdx: number): string {
  return HOUSE_DOMAIN[houseIdx].replace("the arena of", "the field of");
}

// A short, explicitly fictional, deliberately cheeky hero's journey (paid layer).
// It walks the whole enneagram in story form — Sun through Saturn — and weaves
// the three thresholds in as plot beats. Fun over poetic; a mirror, not a sermon.
export function generateHeroJourney(
  chart: NatalChart,
  primary: PrimaryArchetype
): HeroJourney {
  const name = chart.input.name?.trim() || "our hero";
  const asc = SIGNS[chart.ascendant.signIndex].name;
  const S = (k: PlanetKey) => SIGNS[chart.positions[k].signIndex].name;
  const H = (k: PlanetKey) => ORDINALS[chart.positions[k].house - 1];
  const F = (k: PlanetKey) => field(chart.positions[k].house - 1);
  const line = primary.line.replace(/\.$/, "");

  return {
    title: `The Mostly True Adventures of ${name}`,
    paragraphs: [
      `Every good story needs a hero who has no idea they are in one — so meet ${name}, who answers the door as ${asc} (all first impressions and quick opinions) but is secretly powered by a ${S("sun")} Sun idling in the ${H("sun")} house. Translation: the whole adventure kicks off in ${F("sun")}, whether ${name} signed up for it or not. (They did not.)`,
      `Before doing anything sensible, ${name} consults the gut. That is the ${S("moon")} Moon in the ${H("moon")} house — a private weather report nobody else can see, usually right, and deeply annoying about refusing to explain why.`,
      `Then comes the part with the sword. A ${S("mars")} Mars in the ${H("mars")} house wants to DO something, immediately, ideally five minutes ago. Cue heroic charging. Cue, also, the first twist: charging harder quietly stops working.`,
      `This is the Impact Threshold — the stretch of map marked "Where Force Becomes Direction." ${name} learns the deeply uncool lesson that effort without aim is just expensive cardio. The force gets pointed on purpose, and — plot magic — things finally start to land.`,
      `Newly aimed, ${name} opens their mouth. A ${S("mercury")} Mercury in the ${H("mercury")} house turns all that motion into words, plans, and the occasional devastating argument. This is where the hero gets clever. Sometimes too clever; it is noted in the reviews.`,
      `Emboldened, ${name} does what every hero does at the midpoint: overreaches. A ${S("jupiter")} Jupiter in the ${H("jupiter")} house leans in and whispers "what if it were BIGGER," and for a glorious while, bigger does feel like better.`,
      `Enter the Will Threshold — "Where Expansion Becomes Purpose." It turns out more options are mostly more ways to get lost, so ${name} has to do the terribly grown-up thing and actually choose. Growth stops being about how much and starts being about what for.`,
      `With the field finally narrowed, ${name} asks the question the whole trip was circling: a ${S("venus")} Venus in the ${H("venus")} house wants to know what is genuinely worth keeping. Taste, worth, the good stuff. The hero stops chasing everything and starts valuing something specific.`,
      `Which leaves the last boss: a ${S("saturn")} Saturn in the ${H("saturn")} house, guarding the Retention Threshold — "Where Structure Becomes Permanence." Saturn never smiles and is always right. It dares ${name} to build the thing so well it survives without them. Cross this one and the lesson stops being a lesson and becomes part of the furniture.`,
      `Moral of the story: the blueprint was never missing — just unread. As ${primary.name}, the one who ${line}, ${name} was fully equipped the entire time. The dragon, it turns out, was a filing problem. Roll credits.`,
    ],
  };
}
