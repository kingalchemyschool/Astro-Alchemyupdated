import { Sparkles } from "lucide-react";
import type { Reading } from "@/types/astro";
import NatalChartSummary from "@/components/features/NatalChartSummary";
import InteractiveEnneagram from "@/components/features/InteractiveEnneagram";
import ArchetypeMap from "@/components/features/ArchetypeMap";
import FullBlueprint from "@/components/features/FullBlueprint";

interface Props {
  reading: Reading;
  premium: boolean;
  onUnlock?: () => void;
}

// Shared body of a blueprint report — reused by the live Reading page and the
// read-only shared Blueprint page. Free flow: enneagram -> the six archetypes ->
// the all-encompassing primary -> the paid full blueprint.
export default function ReportView({ reading, premium, onUnlock }: Props) {
  const { chart, functions, primary } = reading;

  return (
    <>
      <NatalChartSummary chart={chart} />

      {/* Interactive enneagram — free, explains the engines */}
      <section className="mt-10">
        <div className="mb-4">
          <div className="font-mono text-xs uppercase tracking-widest text-accent">
            Interactive Blueprint
          </div>
          <h2 className="mt-1 font-serif text-2xl font-semibold">
            Your creation enneagram
          </h2>
          <p className="text-sm text-muted-foreground">
            Tap any engine to learn its function. Tap the connecting lines to reveal
            your six Alchemist Archetypes.
          </p>
        </div>
        <InteractiveEnneagram
          chart={chart}
          functions={functions}
          premium={premium}
          onUnlock={onUnlock}
        />
      </section>

      {/* Free — all six archetype functions */}
      <section className="mt-12">
        <div className="mb-4">
          <div className="font-mono text-xs uppercase tracking-widest text-accent">
            Alchemist Archetypes
          </div>
          <h2 className="mt-1 font-serif text-2xl font-semibold">
            Your six creative functions
          </h2>
          <p className="text-sm text-muted-foreground">
            Each is a relationship between two engines — and the archetype it resolves
            into for you. Your full blueprint reads all six in depth.
          </p>
        </div>
        <ArchetypeMap functions={functions} primaryKey={primary.functionKey} />
      </section>

      {/* Free — the all-encompassing primary archetype (the synthesis) */}
      <section className="mt-12">
        <div className="mb-4 flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-primary">
          <Sparkles className="h-3.5 w-3.5" /> Your all-encompassing archetype
        </div>
        <div className="rounded-2xl border border-primary/30 bg-primary/[0.05] p-6 blueprint-grid sm:p-8">
          <h2 className="font-serif text-3xl font-semibold">
            You are {primary.name}
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            The single archetype that ties all six of your functions together.
          </p>
          <div className="mt-5 space-y-4 text-[15px] leading-relaxed text-foreground/90">
            {primary.paragraphs.map((p, i) => (
              <p key={i}>{p}</p>
            ))}
          </div>
        </div>
      </section>

      {/* Paid layer */}
      <section className="mt-12">
        <FullBlueprint reading={reading} premium={premium} onUnlock={onUnlock} />
      </section>
    </>
  );
}
