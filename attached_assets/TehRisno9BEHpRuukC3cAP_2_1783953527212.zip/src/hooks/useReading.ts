import { useCallback, useEffect, useState } from "react";
import type { BirthInput, Reading } from "@/types/astro";
import { computeChart } from "@/lib/ephemeris";
import { generateReading } from "@/lib/reading";

const READING_KEY = "astroboros_reading";
const PREMIUM_KEY = "astroboros_premium";

export function useReading() {
  const [reading, setReading] = useState<Reading | null>(null);
  const [premium, setPremium] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(READING_KEY);
      if (raw) {
        const input = JSON.parse(raw) as BirthInput;
        setReading(generateReading(computeChart(input)));
      }
      setPremium(localStorage.getItem(PREMIUM_KEY) === "true");
    } catch {
      // ignore corrupt storage
    }
  }, []);

  const generate = useCallback((input: BirthInput) => {
    const result = generateReading(computeChart(input));
    setReading(result);
    localStorage.setItem(READING_KEY, JSON.stringify(input));
    return result;
  }, []);

  const reset = useCallback(() => {
    setReading(null);
    localStorage.removeItem(READING_KEY);
  }, []);

  const unlockPremium = useCallback(() => {
    setPremium(true);
    localStorage.setItem(PREMIUM_KEY, "true");
  }, []);

  return { reading, generate, reset, premium, unlockPremium };
}
