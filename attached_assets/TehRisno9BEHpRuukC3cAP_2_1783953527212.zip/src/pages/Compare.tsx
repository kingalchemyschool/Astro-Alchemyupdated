import { useState } from "react";
import {
  FlaskConical,
  RotateCcw,
  Check,
  TrendingUp,
  AlertTriangle,
  Wrench,
} from "lucide-react";
import type { BirthInput, Reading } from "@/types/astro";
import { computeChart } from "@/lib/ephemeris";
import { generateReading } from "@/lib/reading";
import { compareCharts, type Comparison } from "@/lib/compare";
import { SIGNS, PLANET_META } from "@/constants/astro";
import BirthDataForm from "@/components/features/BirthDataForm";
import { Button } from "@/components/common/Button";

export default function Compare() {
  const [a, setA] = useState<Reading | null>(null);
  const [b, setB] = useState<Reading | null>(null);
  const [result, setResult] = useState<Comparison | null>(null);

  const make = (input: BirthInput) => generateReading(computeChart(input));

  const reset = () => {
    setA(null);
    setB(null);
    setResult(null);
  };

  if (result) {
    return <Result comparison={result} onReset={reset} />;
  }

  return (
    <div className="container max-w-5xl py-12">
      <header className="mb-10 max-w-2xl">
        <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-accent">
          <FlaskConical className="h-3.5 w-3.5" /> Alchemy Laboratory
        </div>
        <h1 className="mt-2 font-serif text-4xl font-semibold">
          Compare two blueprints
        </h1>
        <p className="mt-3 leading-relaxed text-muted-foreground">
          Place two people in the same laboratory. Astroboros compares all seven
          creative engines and both Alchemist Archetypes to reveal your combined
          strengths, the frictions to watch, and concrete ways to build together.
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-2">
        <Slot label="Person A" reading={a} onEdit={() => setA(null)}>
          <BirthDataForm onGenerate={(i) => setA(make(i))} />
        </Slot>
        <Slot label="Person B" reading={b} onEdit={() => setB(null)}>
          <BirthDataForm onGenerate={(i) => setB(make(i))} />
        </Slot>
      </div>

      <div className="mt-8 flex flex-col items-center gap-3">
        <Button size="lg" disabled={!a || !b} onClick={() => a && b && setResult(compareCharts(a, b))}>
          <FlaskConical className="h-4 w-4" /> Run the Laboratory
        </Button>
        {(a || b) && (
          <button
            onClick={reset}
            className="text-xs font-medium text-muted-foreground transition-colors hover:text-foreground"
          >
            Reset both
          </button>
        )}
      </div>
    </div>
  );
}

function Slot({
  label,
  reading,
  onEdit,
  children,
}: {
  label: string;
  reading: Reading | null;
  onEdit: () => void;
  children: React.ReactNode;
}) {
  if (reading) {
    const sun = SIGNS[reading.chart.positions.sun.signIndex].name;
    const name = reading.chart.input.name?.trim() || label;
    return (
      <div className="flex flex-col justify-center rounded-2xl border border-primary/40 bg-primary/[0.05] p-6">
        <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-primary">
          <Check className="h-3.5 w-3.5" /> {label} ready
        </div>
        <h3 className="mt-2 font-serif text-2xl font-semibold">{name}</h3>
        <p className="mt-1 text-sm text-muted-foreground">
          {sun} sun · {reading.chart.input.place}
        </p>
        <p className="mt-3 text-sm">
          <span className="text-muted-foreground">Primary archetype: </span>
          <span className="font-semibold text-primary">{reading.primary.name}</span>
        </p>
        <button
          onClick={onEdit}
          className="mt-4 self-start text-xs font-medium text-accent hover:underline"
        >
          Edit {label}
        </button>
      </div>
    );
  }
  return (
    <div>
      <div className="mb-3 font-mono text-xs uppercase tracking-widest text-muted-foreground">
        {label}
      </div>
      {children}
    </div>
  );
}

function ListCard({
  icon: Icon,
  title,
  items,
  tone,
}: {
  icon: typeof TrendingUp;
  title: string;
  items: string[];
  tone: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card/60 p-6">
      <h3 className={`mb-3 flex items-center gap-2 font-serif text-xl font-semibold ${tone}`}>
        <Icon className="h-5 w-5" /> {title}
      </h3>
      <ul className="space-y-3">
        {items.map((x, i) => (
          <li key={i} className="flex gap-3 text-sm leading-relaxed text-foreground/85">
            <span className={`mt-2 h-1.5 w-1.5 shrink-0 rounded-full ${tone.replace("text-", "bg-")}`} />
            {x}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Result({
  comparison,
  onReset,
}: {
  comparison: Comparison;
  onReset: () => void;
}) {
  const c = comparison;
  return (
    <div className="container max-w-4xl py-12">
      <div className="mb-10 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
        <div>
          <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-accent">
            <FlaskConical className="h-3.5 w-3.5" /> The Laboratory
          </div>
          <h1 className="mt-1 font-serif text-4xl font-semibold">
            {c.nameA} <span className="text-muted-foreground">×</span> {c.nameB}
          </h1>
        </div>
        <Button variant="outline" size="sm" onClick={onReset}>
          <RotateCcw className="h-4 w-4" /> New comparison
        </Button>
      </div>

      <div className="space-y-4 text-[15px] leading-relaxed text-foreground/90">
        {c.summary.map((p, i) => (
          <p key={i}>{p}</p>
        ))}
      </div>

      {/* Archetype pairing */}
      <section className="mt-10 rounded-2xl border border-primary/30 bg-primary/[0.05] p-6 sm:p-8 blueprint-grid">
        <h2 className="font-serif text-2xl font-semibold">
          {c.archetype.a} <span className="text-muted-foreground">meets</span>{" "}
          {c.archetype.b}
        </h2>
        <div className="mt-4 space-y-3 text-[15px] leading-relaxed text-foreground/90">
          {c.archetype.paragraphs.map((p, i) => (
            <p key={i}>{p}</p>
          ))}
        </div>
      </section>

      {/* Engine by engine */}
      <section className="mt-12">
        <div className="mb-4 border-b border-border/60 pb-2">
          <div className="font-mono text-xs uppercase tracking-widest text-accent">
            Engine by engine
          </div>
          <h2 className="mt-1 font-serif text-2xl font-semibold">
            How each pair of engines interacts
          </h2>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          {c.planetPairs.map((p) => (
            <article key={p.key} className="rounded-xl border border-border bg-card/60 p-5">
              <div className="mb-2 flex items-center gap-2">
                <span className="glyph text-xl text-accent">{PLANET_META[p.key].glyph}</span>
                <h4 className="font-serif text-lg font-semibold">{PLANET_META[p.key].name}</h4>
                <span className="ml-auto font-mono text-xs text-muted-foreground">
                  {p.aSign} / {p.bSign}
                </span>
              </div>
              <p className="text-sm leading-relaxed text-foreground/85">{p.note}</p>
            </article>
          ))}
        </div>
      </section>

      {/* Strengths / frictions / solutions */}
      <section className="mt-12 space-y-6">
        <ListCard icon={TrendingUp} title="Where you amplify each other" items={c.strengths} tone="text-accent" />
        <ListCard icon={AlertTriangle} title="Frictions to watch" items={c.frictions} tone="text-destructive" />
        <ListCard icon={Wrench} title="How to work together" items={c.solutions} tone="text-primary" />
      </section>
    </div>
  );
}
