import { useState } from "react";
import { Compass, MapPin } from "lucide-react";
import { toast } from "sonner";
import type { BirthInput, GeoLocation } from "@/types/astro";
import { TZ_OPTIONS } from "@/constants/astro";
import { getTimezoneOffset } from "@/lib/timezone";
import { Button } from "@/components/common/Button";
import CitySelect from "@/components/features/CitySelect";
import { cn } from "@/lib/utils";

interface Props {
  onGenerate: (input: BirthInput) => void;
}

const inputClass =
  "w-full rounded-md border border-input bg-background/60 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary/60 focus:outline-none focus:ring-1 focus:ring-primary/40";

const labelClass = "mb-1.5 block text-sm font-medium text-foreground/90";

export default function BirthDataForm({ onGenerate }: Props) {
  const [name, setName] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("12:00");
  const [location, setLocation] = useState<GeoLocation | null>(null);
  const [custom, setCustom] = useState(false);
  const [lat, setLat] = useState("");
  const [lon, setLon] = useState("");
  const [tz, setTz] = useState("0");
  const [zodiac, setZodiac] = useState<"tropical" | "sidereal">("tropical");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date) {
      toast.error("Please enter your birth date.");
      return;
    }
    if (!time) {
      toast.error("Please enter your birth time.");
      return;
    }

    let input: BirthInput;
    if (custom) {
      const latN = parseFloat(lat);
      const lonN = parseFloat(lon);
      if (Number.isNaN(latN) || Number.isNaN(lonN)) {
        toast.error("Enter valid latitude and longitude.");
        return;
      }
      input = {
        name: name.trim() || undefined,
        date,
        time,
        place: `${latN.toFixed(2)}, ${lonN.toFixed(2)}`,
        lat: latN,
        lon: lonN,
        tz: parseFloat(tz),
        zodiac,
      };
    } else {
      if (!location) {
        toast.error("Search for and select your birth place.");
        return;
      }
      input = {
        name: name.trim() || undefined,
        date,
        time,
        place: location.name,
        lat: location.lat,
        lon: location.lon,
        tz: getTimezoneOffset(location.tzName, date, time),
        tzName: location.tzName,
        zodiac,
      };
    }

    onGenerate(input);
    toast.success("Blueprint computed.", {
      description: "Your nine-point creation cycle is ready below.",
    });
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="rounded-2xl border border-border bg-card/70 p-6 sm:p-8 blueprint-grid"
    >
      <div className="mb-6 flex items-center gap-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 text-primary">
          <Compass className="h-5 w-5" />
        </div>
        <div>
          <h2 className="font-serif text-xl font-semibold">Enter your birth data</h2>
          <p className="text-sm text-muted-foreground">
            Date, time, and place map your natal chart onto the blueprint.
          </p>
        </div>
      </div>

      <div className="grid gap-5 sm:grid-cols-2">
        <div className="sm:col-span-2">
          <label className={labelClass} htmlFor="name">
            Name <span className="text-muted-foreground">(optional)</span>
          </label>
          <input
            id="name"
            className={inputClass}
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="For your report header"
          />
        </div>

        <div>
          <label className={labelClass} htmlFor="date">
            Birth date
          </label>
          <input
            id="date"
            type="date"
            className={inputClass}
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
          />
        </div>

        <div>
          <label className={labelClass} htmlFor="time">
            Birth time
          </label>
          <input
            id="time"
            type="time"
            className={inputClass}
            value={time}
            onChange={(e) => setTime(e.target.value)}
            required
          />
        </div>

        {!custom ? (
          <div className="sm:col-span-2">
            <label className={labelClass}>Birth place</label>
            <CitySelect value={location} onChange={setLocation} />
            <p className="mt-1.5 text-xs text-muted-foreground">
              Search any city or town worldwide. Time zone and daylight saving are
              resolved automatically from your birth date.
            </p>
          </div>
        ) : (
          <>
            <div>
              <label className={labelClass} htmlFor="lat">
                Latitude
              </label>
              <input
                id="lat"
                className={inputClass}
                value={lat}
                onChange={(e) => setLat(e.target.value)}
                placeholder="e.g. 40.71"
                inputMode="decimal"
              />
            </div>
            <div>
              <label className={labelClass} htmlFor="lon">
                Longitude <span className="text-muted-foreground">(east +)</span>
              </label>
              <input
                id="lon"
                className={inputClass}
                value={lon}
                onChange={(e) => setLon(e.target.value)}
                placeholder="e.g. -74.00"
                inputMode="decimal"
              />
            </div>
            <div className="sm:col-span-2">
              <label className={labelClass} htmlFor="tz">
                UTC offset (hours)
              </label>
              <select
                id="tz"
                className={inputClass}
                value={tz}
                onChange={(e) => setTz(e.target.value)}
              >
                {TZ_OPTIONS.map((t) => (
                  <option key={t} value={t}>
                    UTC{t >= 0 ? "+" : ""}
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </>
        )}
      </div>

      <div className="mt-5">
        <span className={labelClass}>Zodiac system</span>
        <div className="grid grid-cols-2 gap-2">
          {(["tropical", "sidereal"] as const).map((z) => (
            <button
              key={z}
              type="button"
              onClick={() => setZodiac(z)}
              className={cn(
                "rounded-md border px-3 py-2.5 text-sm capitalize transition-colors",
                zodiac === z
                  ? "border-primary/60 bg-primary/10 text-primary"
                  : "border-input bg-background/60 text-muted-foreground hover:text-foreground"
              )}
            >
              {z}
            </button>
          ))}
        </div>
        <p className="mt-1.5 text-xs text-muted-foreground">
          Tropical is the Western default. Sidereal (Lahiri) aligns the signs to the
          constellations. Houses use the Placidus system.
        </p>
      </div>

      <button
        type="button"
        onClick={() => setCustom((c) => !c)}
        className="mt-4 flex items-center gap-1.5 text-xs font-medium text-accent hover:underline"
      >
        <MapPin className="h-3.5 w-3.5" />
        {custom ? "Use city search instead" : "Enter exact coordinates manually"}
      </button>

      <Button type="submit" size="lg" className="mt-6 w-full">
        Generate Creation Blueprint
      </Button>
    </form>
  );
}
