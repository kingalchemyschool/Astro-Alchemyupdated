import type { PlanetKey } from "@/types/astro";

export interface SignInfo {
  name: string;
  glyph: string;
  element: "fire" | "earth" | "air" | "water";
  modality: "cardinal" | "fixed" | "mutable";
}

export const SIGNS: SignInfo[] = [
  { name: "Aries", glyph: "♈", element: "fire", modality: "cardinal" },
  { name: "Taurus", glyph: "♉", element: "earth", modality: "fixed" },
  { name: "Gemini", glyph: "♊", element: "air", modality: "mutable" },
  { name: "Cancer", glyph: "♋", element: "water", modality: "cardinal" },
  { name: "Leo", glyph: "♌", element: "fire", modality: "fixed" },
  { name: "Virgo", glyph: "♍", element: "earth", modality: "mutable" },
  { name: "Libra", glyph: "♎", element: "air", modality: "cardinal" },
  { name: "Scorpio", glyph: "♏", element: "water", modality: "fixed" },
  { name: "Sagittarius", glyph: "♐", element: "fire", modality: "mutable" },
  { name: "Capricorn", glyph: "♑", element: "earth", modality: "cardinal" },
  { name: "Aquarius", glyph: "♒", element: "air", modality: "fixed" },
  { name: "Pisces", glyph: "♓", element: "water", modality: "mutable" },
];

export const ORDINALS = [
  "1st", "2nd", "3rd", "4th", "5th", "6th",
  "7th", "8th", "9th", "10th", "11th", "12th",
];

export interface PlanetInfo {
  name: string;
  glyph: string;
  fn: string; // creation function
  point?: number; // enneagram point (inner planets only)
  octave?: PlanetKey; // outer octave partner
}

export const PLANET_META: Record<PlanetKey, PlanetInfo> = {
  sun: { name: "Sun", glyph: "☉", fn: "Vision", point: 0 },
  moon: { name: "Moon", glyph: "☽", fn: "Perception", point: 1 },
  mars: { name: "Mars", glyph: "♂", fn: "Impact", point: 2, octave: "pluto" },
  mercury: { name: "Mercury", glyph: "☿", fn: "Communication", point: 4, octave: "uranus" },
  jupiter: { name: "Jupiter", glyph: "♃", fn: "Expansion", point: 5 },
  venus: { name: "Venus", glyph: "♀", fn: "Value", point: 7, octave: "neptune" },
  saturn: { name: "Saturn", glyph: "♄", fn: "Foundation", point: 8 },
  pluto: { name: "Pluto", glyph: "♇", fn: "Regeneration" },
  uranus: { name: "Uranus", glyph: "♅", fn: "Disruption" },
  neptune: { name: "Neptune", glyph: "♆", fn: "Dissolution" },
};

// Order used for the summary box display
export const SUMMARY_ORDER: PlanetKey[] = [
  "sun", "moon", "mercury", "venus", "mars",
  "jupiter", "saturn", "uranus", "neptune", "pluto",
];

export interface CityInfo {
  name: string;
  lat: number;
  lon: number; // east positive
  tz: number; // standard UTC offset (fallback)
  tzName: string; // IANA id — drives DST-accurate offset per birth date
}

export const CITIES: CityInfo[] = [
  // North America
  { name: "New York, USA", lat: 40.7128, lon: -74.006, tz: -5, tzName: "America/New_York" },
  { name: "Los Angeles, USA", lat: 34.0522, lon: -118.2437, tz: -8, tzName: "America/Los_Angeles" },
  { name: "Chicago, USA", lat: 41.8781, lon: -87.6298, tz: -6, tzName: "America/Chicago" },
  { name: "Houston, USA", lat: 29.7604, lon: -95.3698, tz: -6, tzName: "America/Chicago" },
  { name: "Phoenix, USA", lat: 33.4484, lon: -112.074, tz: -7, tzName: "America/Phoenix" },
  { name: "Denver, USA", lat: 39.7392, lon: -104.9903, tz: -7, tzName: "America/Denver" },
  { name: "Seattle, USA", lat: 47.6062, lon: -122.3321, tz: -8, tzName: "America/Los_Angeles" },
  { name: "San Francisco, USA", lat: 37.7749, lon: -122.4194, tz: -8, tzName: "America/Los_Angeles" },
  { name: "Miami, USA", lat: 25.7617, lon: -80.1918, tz: -5, tzName: "America/New_York" },
  { name: "Boston, USA", lat: 42.3601, lon: -71.0589, tz: -5, tzName: "America/New_York" },
  { name: "Atlanta, USA", lat: 33.749, lon: -84.388, tz: -5, tzName: "America/New_York" },
  { name: "Honolulu, USA", lat: 21.3069, lon: -157.8583, tz: -10, tzName: "Pacific/Honolulu" },
  { name: "Anchorage, USA", lat: 61.2181, lon: -149.9003, tz: -9, tzName: "America/Anchorage" },
  { name: "Toronto, Canada", lat: 43.6532, lon: -79.3832, tz: -5, tzName: "America/Toronto" },
  { name: "Montreal, Canada", lat: 45.5017, lon: -73.5673, tz: -5, tzName: "America/Toronto" },
  { name: "Vancouver, Canada", lat: 49.2827, lon: -123.1207, tz: -8, tzName: "America/Vancouver" },
  { name: "Mexico City, Mexico", lat: 19.4326, lon: -99.1332, tz: -6, tzName: "America/Mexico_City" },
  { name: "Guadalajara, Mexico", lat: 20.6597, lon: -103.3496, tz: -6, tzName: "America/Mexico_City" },

  // Central & South America
  { name: "Guatemala City, Guatemala", lat: 14.6349, lon: -90.5069, tz: -6, tzName: "America/Guatemala" },
  { name: "Panama City, Panama", lat: 8.9824, lon: -79.5199, tz: -5, tzName: "America/Panama" },
  { name: "Bogotá, Colombia", lat: 4.711, lon: -74.0721, tz: -5, tzName: "America/Bogota" },
  { name: "Lima, Peru", lat: -12.0464, lon: -77.0428, tz: -5, tzName: "America/Lima" },
  { name: "Quito, Ecuador", lat: -0.1807, lon: -78.4678, tz: -5, tzName: "America/Guayaquil" },
  { name: "Caracas, Venezuela", lat: 10.4806, lon: -66.9036, tz: -4, tzName: "America/Caracas" },
  { name: "Santiago, Chile", lat: -33.4489, lon: -70.6693, tz: -4, tzName: "America/Santiago" },
  { name: "Buenos Aires, Argentina", lat: -34.6037, lon: -58.3816, tz: -3, tzName: "America/Argentina/Buenos_Aires" },
  { name: "Montevideo, Uruguay", lat: -34.9011, lon: -56.1645, tz: -3, tzName: "America/Montevideo" },
  { name: "São Paulo, Brazil", lat: -23.5505, lon: -46.6333, tz: -3, tzName: "America/Sao_Paulo" },
  { name: "Rio de Janeiro, Brazil", lat: -22.9068, lon: -43.1729, tz: -3, tzName: "America/Sao_Paulo" },

  // Europe
  { name: "London, UK", lat: 51.5074, lon: -0.1278, tz: 0, tzName: "Europe/London" },
  { name: "Manchester, UK", lat: 53.4808, lon: -2.2426, tz: 0, tzName: "Europe/London" },
  { name: "Dublin, Ireland", lat: 53.3498, lon: -6.2603, tz: 0, tzName: "Europe/Dublin" },
  { name: "Lisbon, Portugal", lat: 38.7223, lon: -9.1393, tz: 0, tzName: "Europe/Lisbon" },
  { name: "Madrid, Spain", lat: 40.4168, lon: -3.7038, tz: 1, tzName: "Europe/Madrid" },
  { name: "Barcelona, Spain", lat: 41.3874, lon: 2.1686, tz: 1, tzName: "Europe/Madrid" },
  { name: "Paris, France", lat: 48.8566, lon: 2.3522, tz: 1, tzName: "Europe/Paris" },
  { name: "Amsterdam, Netherlands", lat: 52.3676, lon: 4.9041, tz: 1, tzName: "Europe/Amsterdam" },
  { name: "Brussels, Belgium", lat: 50.8503, lon: 4.3517, tz: 1, tzName: "Europe/Brussels" },
  { name: "Berlin, Germany", lat: 52.52, lon: 13.405, tz: 1, tzName: "Europe/Berlin" },
  { name: "Munich, Germany", lat: 48.1351, lon: 11.582, tz: 1, tzName: "Europe/Berlin" },
  { name: "Zurich, Switzerland", lat: 47.3769, lon: 8.5417, tz: 1, tzName: "Europe/Zurich" },
  { name: "Milan, Italy", lat: 45.4642, lon: 9.19, tz: 1, tzName: "Europe/Rome" },
  { name: "Rome, Italy", lat: 41.9028, lon: 12.4964, tz: 1, tzName: "Europe/Rome" },
  { name: "Vienna, Austria", lat: 48.2082, lon: 16.3738, tz: 1, tzName: "Europe/Vienna" },
  { name: "Prague, Czechia", lat: 50.0755, lon: 14.4378, tz: 1, tzName: "Europe/Prague" },
  { name: "Warsaw, Poland", lat: 52.2297, lon: 21.0122, tz: 1, tzName: "Europe/Warsaw" },
  { name: "Copenhagen, Denmark", lat: 55.6761, lon: 12.5683, tz: 1, tzName: "Europe/Copenhagen" },
  { name: "Oslo, Norway", lat: 59.9139, lon: 10.7522, tz: 1, tzName: "Europe/Oslo" },
  { name: "Stockholm, Sweden", lat: 59.3293, lon: 18.0686, tz: 1, tzName: "Europe/Stockholm" },
  { name: "Helsinki, Finland", lat: 60.1699, lon: 24.9384, tz: 2, tzName: "Europe/Helsinki" },
  { name: "Athens, Greece", lat: 37.9838, lon: 23.7275, tz: 2, tzName: "Europe/Athens" },
  { name: "Kyiv, Ukraine", lat: 50.4501, lon: 30.5234, tz: 2, tzName: "Europe/Kyiv" },
  { name: "Istanbul, Turkey", lat: 41.0082, lon: 28.9784, tz: 3, tzName: "Europe/Istanbul" },
  { name: "Moscow, Russia", lat: 55.7558, lon: 37.6173, tz: 3, tzName: "Europe/Moscow" },

  // Africa & Middle East
  { name: "Casablanca, Morocco", lat: 33.5731, lon: -7.5898, tz: 1, tzName: "Africa/Casablanca" },
  { name: "Lagos, Nigeria", lat: 6.5244, lon: 3.3792, tz: 1, tzName: "Africa/Lagos" },
  { name: "Cairo, Egypt", lat: 30.0444, lon: 31.2357, tz: 2, tzName: "Africa/Cairo" },
  { name: "Nairobi, Kenya", lat: -1.2921, lon: 36.8219, tz: 3, tzName: "Africa/Nairobi" },
  { name: "Cape Town, South Africa", lat: -33.9249, lon: 18.4241, tz: 2, tzName: "Africa/Johannesburg" },
  { name: "Johannesburg, South Africa", lat: -26.2041, lon: 28.0473, tz: 2, tzName: "Africa/Johannesburg" },
  { name: "Jerusalem, Israel", lat: 31.7683, lon: 35.2137, tz: 2, tzName: "Asia/Jerusalem" },
  { name: "Tel Aviv, Israel", lat: 32.0853, lon: 34.7818, tz: 2, tzName: "Asia/Jerusalem" },
  { name: "Riyadh, Saudi Arabia", lat: 24.7136, lon: 46.6753, tz: 3, tzName: "Asia/Riyadh" },
  { name: "Tehran, Iran", lat: 35.6892, lon: 51.389, tz: 3.5, tzName: "Asia/Tehran" },
  { name: "Dubai, UAE", lat: 25.2048, lon: 55.2708, tz: 4, tzName: "Asia/Dubai" },

  // Asia
  { name: "Karachi, Pakistan", lat: 24.8607, lon: 67.0011, tz: 5, tzName: "Asia/Karachi" },
  { name: "Mumbai, India", lat: 19.076, lon: 72.8777, tz: 5.5, tzName: "Asia/Kolkata" },
  { name: "New Delhi, India", lat: 28.6139, lon: 77.209, tz: 5.5, tzName: "Asia/Kolkata" },
  { name: "Bengaluru, India", lat: 12.9716, lon: 77.5946, tz: 5.5, tzName: "Asia/Kolkata" },
  { name: "Kolkata, India", lat: 22.5726, lon: 88.3639, tz: 5.5, tzName: "Asia/Kolkata" },
  { name: "Colombo, Sri Lanka", lat: 6.9271, lon: 79.8612, tz: 5.5, tzName: "Asia/Colombo" },
  { name: "Kathmandu, Nepal", lat: 27.7172, lon: 85.324, tz: 5.75, tzName: "Asia/Kathmandu" },
  { name: "Dhaka, Bangladesh", lat: 23.8103, lon: 90.4125, tz: 6, tzName: "Asia/Dhaka" },
  { name: "Bangkok, Thailand", lat: 13.7563, lon: 100.5018, tz: 7, tzName: "Asia/Bangkok" },
  { name: "Ho Chi Minh City, Vietnam", lat: 10.8231, lon: 106.6297, tz: 7, tzName: "Asia/Ho_Chi_Minh" },
  { name: "Jakarta, Indonesia", lat: -6.2088, lon: 106.8456, tz: 7, tzName: "Asia/Jakarta" },
  { name: "Kuala Lumpur, Malaysia", lat: 3.139, lon: 101.6869, tz: 8, tzName: "Asia/Kuala_Lumpur" },
  { name: "Singapore", lat: 1.3521, lon: 103.8198, tz: 8, tzName: "Asia/Singapore" },
  { name: "Manila, Philippines", lat: 14.5995, lon: 120.9842, tz: 8, tzName: "Asia/Manila" },
  { name: "Hong Kong", lat: 22.3193, lon: 114.1694, tz: 8, tzName: "Asia/Hong_Kong" },
  { name: "Taipei, Taiwan", lat: 25.033, lon: 121.5654, tz: 8, tzName: "Asia/Taipei" },
  { name: "Beijing, China", lat: 39.9042, lon: 116.4074, tz: 8, tzName: "Asia/Shanghai" },
  { name: "Shanghai, China", lat: 31.2304, lon: 121.4737, tz: 8, tzName: "Asia/Shanghai" },
  { name: "Seoul, South Korea", lat: 37.5665, lon: 126.978, tz: 9, tzName: "Asia/Seoul" },
  { name: "Tokyo, Japan", lat: 35.6762, lon: 139.6503, tz: 9, tzName: "Asia/Tokyo" },
  { name: "Osaka, Japan", lat: 34.6937, lon: 135.5023, tz: 9, tzName: "Asia/Tokyo" },

  // Oceania
  { name: "Perth, Australia", lat: -31.9523, lon: 115.8613, tz: 8, tzName: "Australia/Perth" },
  { name: "Adelaide, Australia", lat: -34.9285, lon: 138.6007, tz: 9.5, tzName: "Australia/Adelaide" },
  { name: "Brisbane, Australia", lat: -27.4698, lon: 153.0251, tz: 10, tzName: "Australia/Brisbane" },
  { name: "Melbourne, Australia", lat: -37.8136, lon: 144.9631, tz: 10, tzName: "Australia/Melbourne" },
  { name: "Sydney, Australia", lat: -33.8688, lon: 151.2093, tz: 10, tzName: "Australia/Sydney" },
  { name: "Auckland, New Zealand", lat: -36.8485, lon: 174.7633, tz: 12, tzName: "Pacific/Auckland" },
  { name: "Wellington, New Zealand", lat: -41.2865, lon: 174.7762, tz: 12, tzName: "Pacific/Auckland" },
  { name: "Suva, Fiji", lat: -18.1416, lon: 178.4419, tz: 12, tzName: "Pacific/Fiji" },
];

export const TZ_OPTIONS = [
  -12, -11, -10, -9, -8, -7, -6, -5, -4, -3.5, -3, -2, -1,
  0, 1, 2, 3, 3.5, 4, 4.5, 5, 5.5, 5.75, 6, 6.5, 7, 8, 8.75,
  9, 9.5, 10, 10.5, 11, 12, 12.75, 13,
];

// Short quality phrase per sign (indexed by signIndex) — makes readings
// specific rather than generic.
export const SIGN_QUALITY: string[] = [
  "direct, pioneering, and driven to begin", // Aries
  "grounded, deliberate, and built to endure", // Taurus
  "quick, curious, and endlessly associative", // Gemini
  "protective, tidal, and attuned to what needs care", // Cancer
  "radiant, expressive, and organized around a creative center", // Leo
  "precise, analytical, and devoted to refinement", // Virgo
  "relational, balancing, and tuned to proportion", // Libra
  "intense, penetrating, and unwilling to stay on the surface", // Scorpio
  "expansive, exploratory, and aimed at meaning", // Sagittarius
  "strategic, disciplined, and structured for the long climb", // Capricorn
  "inventive, systemic, and oriented toward what is next", // Aquarius
  "fluid, imaginative, and permeable to the unseen", // Pisces
];

// House domain ("the arena of ...") indexed 0-11 for houses 1-12.
export const HOUSE_DOMAIN: string[] = [
  "the arena of identity, presence, and self-initiation",
  "the arena of resources, worth, and material value",
  "the arena of language, learning, and local exchange",
  "the arena of roots, home, and inner foundation",
  "the arena of play, performance, and creative output",
  "the arena of craft, systems, and refinement",
  "the arena of partnership and reflection",
  "the arena of shared power and transformation",
  "the arena of vision, meaning, and expansion",
  "the arena of public work, status, and legacy",
  "the arena of networks, alliances, and the future",
  "the arena of the subconscious, source, and retreat",
];

// How energy "finds expression through ..." in each house.
export const HOUSE_THROUGH: string[] = [
  "self-initiation, presence, and the way you enter a room",
  "resources, worth, and what you choose to build value around",
  "ideas, communication, curiosity, and shared understanding",
  "roots, home, memory, and the private foundation beneath the work",
  "play, performance, and authored creative output",
  "craft, routine, health, and the refinement of process",
  "partnership, negotiation, and the mirror of other people",
  "shared power, intimacy, and cycles of ending and renewal",
  "belief, travel, teaching, and the search for larger meaning",
  "public work, status, ambition, and visible legacy",
  "networks, alliances, and future-oriented vision",
  "solitude, the unconscious, and the dissolving of boundaries",
];

// What the function is "most productive when the work involves ...".
export const HOUSE_WORK: string[] = [
  "launching visible, self-authored beginnings",
  "building steady value and naming what you are worth",
  "translating raw signal into transmissible ideas",
  "securing the private base the work grows from",
  "putting authored expression into the open",
  "tuning process until the work runs clean",
  "shaping the work through the mirror of others",
  "regenerating through depth, merger, and crisis",
  "extending the work toward larger significance",
  "delivering the work into the world as reputation",
  "distributing the work across community and time",
  "drawing material from the hidden and unformed",
];

// Free planet-function explainers for the interactive enneagram.
export const PLANET_ABOUT: Record<PlanetKey, string> = {
  sun: "Vision — the origin of your creative force. The Sun describes what you are here to bring into being and the core intent every other engine serves.",
  moon: "Perception — how you receive and read reality. The Moon gathers sensation, memory, and instinct, turning raw experience into felt understanding.",
  mars: "Impact — how you apply force. Mars converts awareness into action: the first physical push that moves an idea against resistance.",
  mercury: "Communication — how you encode and transmit. Mercury turns force and perception into language, thought, and repeatable signal.",
  jupiter: "Expansion — how you grow. Jupiter increases the range, reach, and possibility of whatever it touches.",
  venus: "Value — how you refine worth. Venus selects what is meaningful and desirable, distilling expansion into something worth keeping.",
  saturn: "Foundation — how you build to last. Saturn provides structure, boundaries, and the discipline that lets creation endure.",
  pluto: "Regeneration — Mars's higher octave. Pluto intensifies force into transformation, dismantling the obsolete so a stronger form can emerge.",
  uranus: "Disruption — Mercury's higher octave. Uranus injects sudden insight and pattern-breaking signal, upgrading communication into invention.",
  neptune: "Dissolution — Venus's higher octave. Neptune dissolves ordinary value into the ideal, drawing worth toward vision and meaning.",
};
