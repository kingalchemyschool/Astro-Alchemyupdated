import type {
  ArchetypeFunction,
  NatalChart,
  PlanetKey,
  PrimaryArchetype,
  Aspect,
} from "@/types/astro";
import { FUNCTIONS, type FunctionMeta, type ArchetypeOption } from "@/constants/archetypes";
import { SIGNS, ORDINALS, PLANET_META, HOUSE_DOMAIN } from "@/constants/astro";
import { aspectBetween } from "@/lib/aspects";

type Element = "fire" | "earth" | "air" | "water";

const ELEMENT_GIFT: Record<Element, string> = {
  fire: "igniting momentum others rally behind",
  earth: "turning intention into durable, usable form",
  air: "connecting scattered ideas into clear, shareable systems",
  water: "sensing meaning and value before it becomes visible",
};

const ELEMENT_EDGE: Record<Element, string> = {
  fire: "pacing the fire so initiatives are finished, not merely started",
  earth: "staying flexible when a structure has outlived its usefulness",
  air: "grounding ideas into committed, embodied action",
  water: "giving intuition a defined form others can actually receive",
};

const ELEMENT_INDEX: Record<Element, number> = { fire: 0, earth: 1, air: 2, water: 3 };

function ord(n: number): string {
  return ORDINALS[n - 1];
}

function field(houseIdx: number): string {
  return HOUSE_DOMAIN[houseIdx].replace("the arena of", "the field of");
}

function aspClause(asp: Aspect | undefined): string {
  if (!asp) {
    return "form no exact aspect, working as two independent systems you must consciously connect";
  }
  const words: Record<Aspect["type"], string> = {
    conjunction: "sit conjunct",
    sextile: "hold a supportive sextile",
    square: "lock into a square",
    trine: "share a flowing trine",
    opposition: "face off in opposition",
  };
  return `${words[asp.type]} (orb ${asp.orb}°)`;
}

function toneFor(chart: NatalChart, a: PlanetKey, b: PlanetKey): string {
  const A = SIGNS[chart.positions[a].signIndex];
  const B = SIGNS[chart.positions[b].signIndex];
  if (A.element === B.element) return "deep resonance";
  if (compatible(A.element, B.element)) return "natural flow";
  if (A.modality === B.modality) return "productive tension";
  return "creative friction";
}

function compatible(a: Element, b: Element): boolean {
  return (
    (a === "fire" && b === "air") ||
    (a === "air" && b === "fire") ||
    (a === "earth" && b === "water") ||
    (a === "water" && b === "earth")
  );
}

function pickArchetype(fn: FunctionMeta, chart: NatalChart): ArchetypeOption {
  const output = fn.pair[1];
  const el = SIGNS[chart.positions[output].signIndex].element as Element;
  const asp = aspectBetween(fn.pair[0], fn.pair[1], chart.aspects);
  const n = fn.archetypes.length;
  let idx = ELEMENT_INDEX[el];
  if (n >= 5 && asp && (asp.type === "square" || asp.type === "opposition")) idx = 4;
  if (idx > n - 1) idx = n - 1;
  return fn.archetypes[idx];
}

function scoreFn(fn: FunctionMeta, asp: Aspect | undefined): number {
  let s = 0;
  if (asp) {
    const w: Record<Aspect["type"], number> = {
      conjunction: 5,
      opposition: 4,
      trine: 4,
      square: 3.5,
      sextile: 2.5,
    };
    s += w[asp.type] + Math.max(0, 3 - asp.orb);
  }
  if (fn.pair.includes("moon")) s += 1.2; // luminary weight
  return Math.round(s * 100) / 100;
}

function functionReading(
  chart: NatalChart,
  fn: FunctionMeta,
  arche: ArchetypeOption,
  asp: Aspect | undefined,
  resonance: string
): string[] {
  const [a, b] = fn.pair;
  const pa = chart.positions[a];
  const pb = chart.positions[b];
  const sa = SIGNS[pa.signIndex];
  const sb = SIGNS[pb.signIndex];
  const el = sb.element as Element;

  const p1 =
    `${fn.title} is the work of ${fn.glyphs[0]} ${PLANET_META[a].name} and ${fn.glyphs[1]} ${PLANET_META[b].name}. ` +
    `${fn.definition} In your chart, ${PLANET_META[a].name} in ${sa.name} (${ord(pa.house)} house) and ${PLANET_META[b].name} in ${sb.name} (${ord(pb.house)} house) ${aspClause(asp)}, producing ${resonance}. ` +
    `This resolves into a clear signature: you operate as ${arche.name} — the one who ${arche.line}`;

  const p2 =
    `Practically, this engine governs ${fn.tagline}. Your natural advantage here is ${ELEMENT_GIFT[el]}; the distortion appears when the process runs unchecked and you lose ${ELEMENT_EDGE[el]}. ` +
    `Tuned well, ${PLANET_META[a].name}'s ${sa.element} instinct and ${PLANET_META[b].name}'s ${sb.element} instinct form a loop that keeps the whole creation cycle honest — the stage where your inner ${arche.name.replace(/^The /, "").toLowerCase()} becomes a repeatable practice rather than an occasional talent.`;

  return [p1, p2];
}

export function deriveFunctions(chart: NatalChart): ArchetypeFunction[] {
  return FUNCTIONS.map((fn) => {
    const [a, b] = fn.pair;
    const asp = aspectBetween(a, b, chart.aspects);
    const arche = pickArchetype(fn, chart);
    const resonance = toneFor(chart, a, b);
    const overview = `${fn.title} — ${fn.tagline}. In your chart this resolves into ${arche.name}.`;
    const reading = functionReading(chart, fn, arche, asp, resonance);
    const score = scoreFn(fn, asp);
    return {
      key: fn.key,
      title: fn.title,
      tagline: fn.tagline,
      pair: fn.pair,
      glyphs: fn.glyphs,
      definition: fn.definition,
      archetypeName: arche.name,
      archetypeLine: arche.line,
      resonance,
      overview,
      reading,
      score,
    };
  });
}

export function derivePrimary(
  functions: ArchetypeFunction[],
  chart: NatalChart
): PrimaryArchetype {
  const top = [...functions].sort((x, y) => y.score - x.score)[0];
  const [a, b] = top.pair;
  const pa = chart.positions[a];
  const pb = chart.positions[b];
  const sa = SIGNS[pa.signIndex];
  const sb = SIGNS[pb.signIndex];
  const el = sb.element as Element;
  const asp = aspectBetween(a, b, chart.aspects);

  const p1 =
    `Read all six functions together and one archetype keeps surfacing as the thread that ties them into a single way of creating. For you that thread is ${top.title} — ${top.glyphs[0]} ${PLANET_META[a].name} and ${top.glyphs[1]} ${PLANET_META[b].name} working as one engine. ` +
    `${top.definition} It resolves into a clear identity that runs through every function above: you are ${top.archetypeName}, the one who ${top.archetypeLine}`;

  const p2 =
    `${PLANET_META[a].name} sits in ${sa.name} in your ${ord(pa.house)} house (${field(pa.house - 1)}), while ${PLANET_META[b].name} sits in ${sb.name} in your ${ord(pb.house)} house (${field(pb.house - 1)}). ` +
    `The two ${aspClause(asp)}, giving this signature ${top.resonance}. This is the engine behind ${top.tagline}.`;

  const p3 =
    `As ${top.archetypeName}, your natural advantage is ${ELEMENT_GIFT[el]}; your growth edge is ${ELEMENT_EDGE[el]}. ` +
    `This is the surface layer of your blueprint. The full reading maps all six Alchemist Archetypes in depth, decodes every planetary engine around your enneagram, and writes a hero's journey drawn from your exact placements.`;

  return {
    functionKey: top.key,
    name: top.archetypeName,
    line: top.archetypeLine,
    paragraphs: [p1, p2, p3],
  };
}
