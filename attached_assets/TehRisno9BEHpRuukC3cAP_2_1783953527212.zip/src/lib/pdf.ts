import { jsPDF } from "jspdf";
import type { Reading } from "@/types/astro";
import { SIGNS, SUMMARY_ORDER, PLANET_META, ORDINALS } from "@/constants/astro";
import { formatDegree } from "@/lib/ephemeris";

// jsPDF core fonts only cover Latin-1, so strip/convert astrological glyphs and
// typographic punctuation to safe equivalents.
const clean = (s: string) =>
  s
    .replace(/→/g, "->")
    .replace(/℞/g, "(R)")
    .replace(/[’‘]/g, "'")
    .replace(/[“”]/g, '"')
    .replace(/[—–]/g, "-")
    .replace(/[·•]/g, "-")
    .replace(/◬/g, "")
    .replace(/…/g, "...")
    .replace(/[^\x00-\xFF]/g, "")
    .replace(/[ ]{2,}/g, " ")
    .trim();

export function exportReadingPdf(reading: Reading, includePremium: boolean) {
  const { chart, planetSections, functions, primary, heroJourney } = reading;
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const pageW = doc.internal.pageSize.getWidth();
  const pageH = doc.internal.pageSize.getHeight();
  const margin = 48;
  const maxW = pageW - margin * 2;
  let y = margin;

  const ensure = (needed: number) => {
    if (y + needed > pageH - margin) {
      doc.addPage();
      y = margin;
    }
  };

  const heading = (text: string, size: number) => {
    ensure(size + 14);
    doc.setFont("times", "bold");
    doc.setFontSize(size);
    doc.setTextColor(24, 26, 40);
    doc.text(clean(text), margin, y);
    y += size + 6;
  };

  const sub = (text: string) => {
    ensure(16);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9.5);
    doc.setTextColor(120, 120, 135);
    doc.text(clean(text), margin, y);
    y += 15;
  };

  const para = (text: string) => {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10.5);
    doc.setTextColor(45, 47, 60);
    const lines = doc.splitTextToSize(clean(text), maxW) as string[];
    for (const line of lines) {
      ensure(15);
      doc.text(line, margin, y);
      y += 14.5;
    }
    y += 8;
  };

  // Cover
  doc.setFont("times", "bold");
  doc.setFontSize(30);
  doc.setTextColor(24, 26, 40);
  doc.text("ASTROBOROS", margin, y + 8);
  y += 40;
  doc.setFont("times", "italic");
  doc.setFontSize(13);
  doc.setTextColor(150, 120, 60);
  doc.text("A Creation Blueprint", margin, y);
  y += 30;

  heading(chart.input.name ? chart.input.name : "Your Reading", 20);
  sub(
    `${chart.input.place}   |   ${chart.input.date}   |   ${chart.input.time}   |   ${
      chart.zodiac === "sidereal" ? "Sidereal (Lahiri)" : "Tropical"
    } - Placidus`
  );
  y += 10;

  // Natal chart summary
  heading("Natal Chart Summary", 15);
  const cols = [margin, margin + 160, margin + 300, margin + 410];
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(120, 120, 135);
  ensure(16);
  doc.text("PLANET", cols[0], y);
  doc.text("SIGN", cols[1], y);
  doc.text("DEGREE", cols[2], y);
  doc.text("HOUSE", cols[3], y);
  y += 15;

  const row = (a: string, b: string, c: string, d: string) => {
    ensure(15);
    doc.setFont("helvetica", "normal");
    doc.setFontSize(10);
    doc.setTextColor(45, 47, 60);
    doc.text(clean(a), cols[0], y);
    doc.text(clean(b), cols[1], y);
    doc.text(clean(c), cols[2], y);
    doc.text(clean(d), cols[3], y);
    y += 14.5;
  };

  const asc = chart.ascendant;
  row("Ascendant", SIGNS[asc.signIndex].name, formatDegree(asc), "1st");
  for (const key of SUMMARY_ORDER) {
    const pos = chart.positions[key];
    row(
      PLANET_META[key].name + (pos.retrograde ? " (R)" : ""),
      SIGNS[pos.signIndex].name,
      formatDegree(pos),
      ORDINALS[pos.house - 1]
    );
  }
  y += 14;

  // Free layer — primary archetype
  heading("Your Alchemist Archetype", 16);
  sub(primary.name);
  for (const p of primary.paragraphs) para(p);

  if (includePremium) {
    // Planet engines + thresholds (woven in cycle order)
    doc.addPage();
    y = margin;
    heading("The Engines & Thresholds", 16);
    for (const s of planetSections) {
      heading(s.title, 13);
      sub(s.subtitle);
      for (const p of s.paragraphs) para(p);
    }

    // Alchemist Archetypes (deep)
    doc.addPage();
    y = margin;
    heading("The Six Alchemist Archetypes", 16);
    for (const f of functions) {
      heading(`${f.title} — ${f.archetypeName}`, 13);
      sub(`${f.tagline}  |  ${f.resonance}`);
      for (const p of f.reading) para(p);
    }

    // Hero's journey
    doc.addPage();
    y = margin;
    heading(heroJourney.title, 16);
    for (const p of heroJourney.paragraphs) para(p);
  }

  const safeName =
    (chart.input.name || "blueprint")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-|-$/g, "") || "blueprint";
  doc.save(`astroboros-${safeName}.pdf`);
}
