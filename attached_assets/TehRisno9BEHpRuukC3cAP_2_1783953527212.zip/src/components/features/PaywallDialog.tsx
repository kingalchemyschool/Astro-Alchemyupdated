import { useState } from "react";
import { Lock, Loader2, CreditCard, ShieldCheck, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/common/Button";

interface Props {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function PaywallDialog({ open, onClose, onSuccess }: Props) {
  const [processing, setProcessing] = useState(false);

  if (!open) return null;

  const handlePay = () => {
    setProcessing(true);
    // Simulated checkout (mock). Real Stripe checkout can be wired later.
    setTimeout(() => {
      setProcessing(false);
      onSuccess();
      onClose();
      toast.success("Alchemical Supervision unlocked", {
        description: "The supervisory layer of your blueprint is now visible.",
      });
    }, 1600);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md rounded-2xl border border-border bg-card p-7 shadow-2xl animate-fade-in-up"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          aria-label="Close"
          className="absolute right-4 top-4 text-muted-foreground hover:text-foreground"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="mb-5 flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Lock className="h-6 w-6" />
        </div>
        <h3 className="font-serif text-2xl font-semibold">Unlock Alchemical Supervision</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          Reveal the six supervisory relationships between your planetary functions —
          the self-correcting feedback loops that refine your entire creation cycle.
        </p>

        <div className="my-6 rounded-lg border border-border bg-secondary/40 p-4">
          <div className="flex items-end justify-between">
            <span className="text-sm text-muted-foreground">Premium Reading</span>
            <span className="font-serif text-3xl font-semibold text-gradient-gold">
              $33
            </span>
          </div>
          <ul className="mt-3 space-y-1.5 text-sm text-foreground/80">
            <li className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent" /> All six supervision cycles
            </li>
            <li className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent" /> Harmony & conflict mapping
            </li>
            <li className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-accent" /> Lifetime access to this blueprint
            </li>
          </ul>
        </div>

        <Button className="w-full" size="lg" onClick={handlePay} disabled={processing}>
          {processing ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Processing…
            </>
          ) : (
            <>
              <CreditCard className="h-4 w-4" /> Complete Checkout
            </>
          )}
        </Button>
        <p className="mt-3 text-center font-mono text-xs text-muted-foreground">
          Simulated checkout — no real charge.
        </p>
      </div>
    </div>
  );
}
