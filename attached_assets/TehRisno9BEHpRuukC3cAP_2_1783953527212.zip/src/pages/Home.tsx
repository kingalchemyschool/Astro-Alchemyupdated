import { Link } from "react-router-dom";
import {
  ArrowRight,
  Circle,
  GitBranch,
  Layers,
  BookOpen,
  Compass,
  Flame,
  Hammer,
  RefreshCw } from
"lucide-react";
import { Button } from "@/components/common/Button";
import heroImg from "@/assets/hero-blueprint.png";

const POINTS = [
{ n: 0, glyph: "☉", name: "Sun", fn: "Vision" },
{ n: 1, glyph: "☽", name: "Moon", fn: "Perception" },
{ n: 2, glyph: "♂", name: "Mars + Pluto", fn: "Impact" },
{ n: 3, glyph: "◬", name: "Threshold 1", fn: "Being" },
{ n: 4, glyph: "☿", name: "Mercury + Uranus", fn: "Communication" },
{ n: 5, glyph: "♃", name: "Jupiter", fn: "Expansion" },
{ n: 6, glyph: "◬", name: "Threshold 2", fn: "Will" },
{ n: 7, glyph: "♀", name: "Venus + Neptune", fn: "Value" },
{ n: 8, glyph: "♄", name: "Saturn", fn: "Foundation" }];


const STRUGGLES = [
{
  icon: BookOpen,
  text: "Studying everybody else's blueprint instead of trusting your own creative genius."
},
{
  icon: Compass,
  text: "Following strategies that weren't designed for your energy, strengths, or patterns."
},
{
  icon: Flame,
  text: "Trying to force outcomes through methods that create friction instead of flow."
},
{
  icon: Hammer,
  text: "Building without understanding the unique way your vision is meant to move through the world."
},
{
  icon: RefreshCw,
  text: "Repeating cycles of effort and burnout without knowing what needs to be refined, redirected, or transformed."
}];


export default function Home() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img
            src={heroImg}
            alt="Celestial architectural blueprint of a nine-point creation cycle"
            className="h-full w-full object-cover opacity-40" />
          
          <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background" />
        </div>
        <div className="container relative py-24 sm:py-32">
          <div className="max-w-3xl animate-fade-in-up">
            <span className="inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 font-mono text-xs uppercase tracking-widest text-primary">
              <Circle className="h-3 w-3 fill-primary" /> Creation Blueprint Engine
            </span>
            <h1 className="mt-6 font-serif text-5xl font-semibold leading-[1.05] sm:text-6xl">
              Turn the prima materia of your chart into{" "}
              <span className="text-gradient-gold">intentional acts of creation.</span>
            </h1>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-foreground/80">Astroboros is a modern blueprint of your astrological placements through the lens of a 9-point alchemical system, revealing your creative impact and the unique rhythm in which you create.




            </p>
            <div className="mt-8 flex flex-wrap items-center gap-4">
              <Link to="/reading">
                <Button size="lg">
                  Get your free blueprint <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
              <a href="#system">
                <Button size="lg" variant="outline">
                  How the system works
                </Button>
              </a>
            </div>
            <p className="mt-4 font-mono text-xs text-muted-foreground">
              No account required · Full alchemical reading available for $33.
            </p>
          </div>
        </div>
      </section>

      {/* Statement band */}
      <section className="border-y border-border/60 bg-card/40">
        <div className="container py-16">
          <p className="max-w-4xl font-serif text-2xl leading-relaxed text-foreground/90 sm:text-3xl">
            Your chart is not simply a collection of personality traits; it is a{" "}
            <span className="text-gradient-gold">living blueprint</span> of your
            creative mechanics — revealing how your energy flows, transforms, and
            expresses itself through the world.
          </p>
        </div>
      </section>

      {/* The problem */}
      <section className="container py-20">
        <div className="mb-10 max-w-2xl">
          <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-accent">
            <RefreshCw className="h-3.5 w-3.5" /> The Missing Manual
          </div>
          <h2 className="mt-2 font-serif text-4xl font-semibold">
            But nobody taught you how to read your blueprint.
          </h2>
          <p className="mt-3 text-muted-foreground">So you have been:</p>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {STRUGGLES.map(({ icon: Icon, text }, i) =>
          <div
            key={i}
            className={`flex items-start gap-4 rounded-xl border border-border bg-card/60 p-5 transition-all hover:-translate-y-0.5 hover:border-accent/50 ${
            i === STRUGGLES.length - 1 ? "md:col-span-2" : ""}`
            }>
            
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-accent/40 bg-accent/10 text-accent">
                <Icon className="h-5 w-5" />
              </span>
              <p className="text-[15px] leading-relaxed text-foreground/85">{text}</p>
            </div>
          )}
        </div>

        <div className="mt-12 rounded-2xl border border-primary/30 bg-primary/[0.05] p-8 sm:p-12">
          <p className="font-serif text-2xl font-medium leading-snug sm:text-3xl">Every birth chart contains a unique pattern of creation.

          </p>
          <p className="mt-2 font-serif text-2xl leading-snug text-gradient-gold sm:text-3xl">Astroboros reveals how that pattern unfolds—how your energy naturally moves, where it transforms, where it becomes blocked, and what requires refinement to fully embody your creative impact.


          </p>
          <p className="mt-5 max-w-3xl leading-relaxed text-foreground/80">Astroboros reveals how that pattern unfolds—how your energy naturally moves, where it transforms, where it becomes blocked, and what requires refinement to fully embody your creative impact.




          </p>
        </div>
      </section>

      {/* Nine-point system */}
      <section id="system" className="container py-8 pb-20">
        <div className="mb-12 max-w-2xl">
          <div className="flex items-center gap-2 font-mono text-xs uppercase tracking-widest text-accent">
            <GitBranch className="h-3.5 w-3.5" /> The Fixed Structure
          </div>
          <h2 className="mt-2 font-serif text-4xl font-semibold">
            One continuous creation cycle
          </h2>
          <p className="mt-3 text-muted-foreground">
            Every reading moves through the blueprint in order — from Vision to
            Foundation — with three thresholds where something inside the creator must
            transform before energy can keep moving.
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {POINTS.map((p) => {
            const isThreshold = p.glyph === "◬";
            return (
              <div
                key={p.n}
                className={`group rounded-xl border p-5 transition-all hover:-translate-y-1 ${
                isThreshold ?
                "border-primary/40 bg-primary/[0.04]" :
                "border-border bg-card/60 hover:border-accent/50"}`
                }>
                
                <div className="flex items-center gap-3">
                  <span
                    className={`glyph flex h-12 w-12 items-center justify-center rounded-lg border text-2xl ${
                    isThreshold ?
                    "border-primary/50 text-primary" :
                    "border-accent/40 text-accent"}`
                    }>
                    
                    {p.glyph}
                  </span>
                  <div>
                    

                    
                    <div className="font-serif text-lg font-semibold">{p.name}</div>
                  </div>
                </div>
                <p className="mt-3 text-sm text-muted-foreground">{p.fn}</p>
              </div>);

          })}
        </div>
      </section>

      {/* Creation → wealth + premium teaser */}
      <section className="container pb-24">
        <div className="mb-8 max-w-3xl">
          <h2 className="font-serif text-3xl font-semibold">
            Creation is more than self-expression.
          </h2>
          <p className="mt-3 leading-relaxed text-foreground/80">
            It is the process of transforming ideas into movements, businesses, art,
            relationships, and lasting value — the foundation from which meaningful
            wealth can be built. When you understand your creation mechanics, you stop
            creating through trial and error and begin building with intention.
          </p>
        </div>

        <div className="grid items-center gap-8 rounded-2xl border border-border bg-card/50 p-8 sm:p-12 lg:grid-cols-2">
          
















          
          <div>
            <div className="font-mono text-xs uppercase tracking-widest text-accent">
              The Six Alchemist Archetypes
            </div>
            <p className="mt-2 text-sm leading-relaxed text-foreground/80">
              Six relationships between your engines generate the functions that turn
              raw potential into value — Translation, Execution, Discipline, Capacity,
              Cultivation, and Integration. Your free reading derives your primary
              archetype from these.
            </p>
          </div>
          <ul className="space-y-3 font-mono text-sm">
            {[
            "Translation · Moon + Mercury",
            "Execution · Mercury + Mars",
            "Discipline · Mars + Saturn",
            "Capacity · Saturn + Jupiter",
            "Cultivation · Jupiter + Venus",
            "Integration · Venus + Moon"].
            map((x) =>
            <li
              key={x}
              className="flex items-center gap-3 rounded-lg border border-border/60 bg-background/40 px-4 py-3">
              
                <span className="h-1.5 w-1.5 rounded-full bg-accent" />
                {x}
              </li>
            )}
          </ul>
        </div>
      </section>
    </div>);

}